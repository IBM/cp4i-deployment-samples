var hm = require('header-metadata'),
    service = require('service-metadata');

//console.info('Count-Based-Test-log: Count-based rate-limiting test flow has started!');

var serviceAddress = service.getVar("var://service/local-service-address");
var serviceIdentity = service.getVar("var://service/system/ident");

session.output.write('Backend responder');
service.mpgw.skipBackside = true;
hm.response.statusCode = 200;
hm.response.set("Service-Address", serviceAddress);
hm.response.set("Service-identity", serviceIdentity);