package com.ibm.demo;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Types;

import org.postgresql.util.PSQLException;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbDatabaseException;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbJSON;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbNode.JDBC_TransactionType;

public class DBWriter_INSERT extends MbJavaComputeNode {

//	Uncomment to debug	
//	private void printElement(MbElement element, String indentation) {
//	    try {
//			System.out.println(indentation + "name:" + element.getName());
//		    System.out.println(indentation + "value:" + element.getValueAsString());
//		    MbElement child = element.getFirstChild();
//		    indentation = indentation + "  ";
//		    while(child != null) {
//		      printElement(child, indentation);
//		      child = child.getNextSibling();
//		     }
//	    }
//	    catch ( Exception e){
//	    	e.printStackTrace();
//	    }
//	    
//	  }
	
	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
//	    Uncomment to debug
//	    MbElement root = inAssembly.getMessage().getRootElement();
//	    System.out.println("root: " + root);
//	    printElement(root, "");

		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alt = getOutputTerminal("alternate");

		MbMessage inMessage = inAssembly.getMessage();
		MbMessageAssembly outAssembly = null;
		try {
			// create new message as a copy of the input
			MbMessage outMessage = new MbMessage(inMessage);
			outAssembly = new MbMessageAssembly(inAssembly, outMessage);
			// ----------------------------------------------------------
			// Add user code below
			try        
			{
				System.out.println("Rate throttling for one second");
			    Thread.sleep(1000);
			} 
			catch(InterruptedException ex) 
			{
			    Thread.currentThread().interrupt();
			}
			System.out.println("Getting message from MQ queue to write in database");
			// JSON/Data is the path JSON format of the MQ message
			MbElement DataRoot = outMessage.getRootElement().getLastChild().getFirstElementByPath("/JSON/Data");
			// Obtain a java.sql.Connection using a JDBC Type4 datasource
	        // This example uses a Policy of type JDBCProviders called "MyJDBCPolicy" in Policy Project "MyPolicies"  
	        Connection conn = getJDBCType4Connection("{DefaultPolicies}:PostgresqlPolicy", JDBC_TransactionType.MB_TRANSACTION_AUTO);
	        // Example of using the Connection to create a java.sql.Statement 
	        //Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);	

	        Object name = DataRoot.getFirstElementByPath("name").getValue();
	        Object email = DataRoot.getFirstElementByPath("email").getValue();
    		Object age = DataRoot.getFirstElementByPath("age").getValue();
    		Object address = DataRoot.getFirstElementByPath("address").getValue();
    		Object usState = DataRoot.getFirstElementByPath("usState").getValue();
    		Object licensePlate = DataRoot.getFirstElementByPath("licensePlate").getValue();
    		Object descriptionOfDamage = DataRoot.getFirstElementByPath("descriptionOfDamage").getValue();
    		Object quoteid = DataRoot.getFirstElementByPath("quoteid").getValue();
    		Object source = "Mobile";
    		Object claimStatus = 1;
    		
    		// checking and converting if age is string, age has to be an integer
	        if ( age != null ) {
	        	try {
	        		age= Integer.valueOf(age.toString());
	        	}
	        	catch ( NumberFormatException e) {
	        		age=null;
	        	}
	        }

	        // Constructing the SQL Query
	        String sql = "INSERT INTO QUOTES(Name, Email, Age, Address, USState, LicensePlate, DescriptionOfDamage, QuoteID, Source, ClaimStatus) "
	        		+ "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?) RETURNING *";
	        
	        PreparedStatement pstmt = conn.prepareStatement(sql);
	        pstmt.setObject(1, name);
	        pstmt.setObject(2, email);
	        pstmt.setObject(3, age);
	        pstmt.setObject(4, address);
	        pstmt.setObject(5, usState);
	        pstmt.setObject(6, licensePlate);
	        pstmt.setObject(7, descriptionOfDamage);
	        pstmt.setObject(8, quoteid);
	        pstmt.setObject(9, source);
	        pstmt.setObject(10, claimStatus);
	        
	        System.out.println("SQL String: " + pstmt.toString());
	        // executing the above query
	        ResultSet rs = pstmt.executeQuery();       
	        
			// End of user code
			// ----------------------------------------------------------
		} catch (MbException e) {
			// Re-throw to allow Broker handling of MbException
			e.printStackTrace();
		} catch (RuntimeException e) {
			// Re-throw to allow Broker handling of RuntimeException
			e.printStackTrace();
        } catch (PSQLException pe) {
        	pe.printStackTrace();
        	throw new MbDatabaseException("PreparedStatement", "executeQuery", "Quote", "msgKey", pe.getMessage(), new Object[0]);
        } catch (Exception e) {
			e.printStackTrace();
		}
		// The following should only be changed
		// if not propagating message to the 'out' terminal
		out.propagate(outAssembly);

	}

	/**
	 * onPreSetupValidation() is called during the construction of the node
	 * to allow the node configuration to be validated.  Updating the node
	 * configuration or connecting to external resources should be avoided.
	 *
	 * @throws MbException
	 */
	@Override
	public void onPreSetupValidation() throws MbException {
	}

	/**
	 * onSetup() is called during the start of the message flow allowing
	 * configuration to be read/cached, and endpoints to be registered.
	 *
	 * Calling getPolicy() within this method to retrieve a policy links this
	 * node to the policy. If the policy is subsequently redeployed the message
	 * flow will be torn down and reinitialized to it's state prior to the policy
	 * redeploy.
	 *
	 * @throws MbException
	 */
	@Override
	public void onSetup() throws MbException {
	}

	/**
	 * onStart() is called as the message flow is started. The thread pool for
	 * the message flow is running when this method is invoked.
	 *
	 * @throws MbException
	 */
	@Override
	public void onStart() throws MbException {
	}

	/**
	 * onStop() is called as the message flow is stopped. 
	 *
	 * The onStop method is called twice as a message flow is stopped. Initially
	 * with a 'wait' value of false and subsequently with a 'wait' value of true.
	 * Blocking operations should be avoided during the initial call. All thread
	 * pools and external connections should be stopped by the completion of the
	 * second call.
	 *
	 * @throws MbException
	 */
	@Override
	public void onStop(boolean wait) throws MbException {
	}

	/**
	 * onTearDown() is called to allow any cached data to be released and any
	 * endpoints to be deregistered.
	 *
	 * @throws MbException
	 */
	@Override
	public void onTearDown() throws MbException {
	}

}
